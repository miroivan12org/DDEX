﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication7.Models;

namespace WebApplication7.Controllers
{
    public class testAPIController : ApiController
    {
        private dataContext db = new dataContext();

        // GET: api/testAPI
        public IQueryable<Osoba> GetOsobas()
        {
            return db.Osobas;
        }

        // GET: api/testAPI/5
        [ResponseType(typeof(Osoba))]
        public IHttpActionResult GetOsoba(Guid id)
        {
            Osoba osoba = db.Osobas.Find(id);
            if (osoba == null)
            {
                return NotFound();
            }

            return Ok(osoba);
        }

        // PUT: api/testAPI/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutOsoba(Guid id, Osoba osoba)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != osoba.ID)
            {
                return BadRequest();
            }

            db.Entry(osoba).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OsobaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/testAPI
        [ResponseType(typeof(Osoba))]
        public IHttpActionResult PostOsoba(Osoba osoba)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Osobas.Add(osoba);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (OsobaExists(osoba.ID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = osoba.ID }, osoba);
        }

        // DELETE: api/testAPI/5
        [ResponseType(typeof(Osoba))]
        public IHttpActionResult DeleteOsoba(Guid id)
        {
            Osoba osoba = db.Osobas.Find(id);
            if (osoba == null)
            {
                return NotFound();
            }

            db.Osobas.Remove(osoba);
            db.SaveChanges();

            return Ok(osoba);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool OsobaExists(Guid id)
        {
            return db.Osobas.Count(e => e.ID == id) > 0;
        }
    }
}