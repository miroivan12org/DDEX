﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication7.Models;

namespace WebApplication7.Controllers
{
    public class OsobaController : Controller
    {
        private dataContext db = new dataContext();

        public static List<Osoba> Osobe { get; set; } = new List<Osoba>() { new Osoba { ID = Guid.NewGuid(), Ime = "pero", Prezime = "perić" } };
        
        public ActionResult Index()
        {
            return View(OsobaController.Osobe);
            //return View(db.Osobas.ToList());
        }
    
        public JsonResult GetIndex()
        {
            return Json(Osobe, JsonRequestBehavior.AllowGet);
        }

        // GET: Osobas/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            //Osoba osoba = db.Osobas.Find(id);
            Osoba osoba = OsobaController.Osobe.Find(x => x.ID == id);
            if (osoba == null)
            {
                return HttpNotFound();
            }
            return View(osoba);
        }

        // GET: Osobas/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Osobas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Ime,Prezime")] Osoba osoba)
        {
            if (ModelState.IsValid)
            {
                osoba.ID = Guid.NewGuid();
                /*db.Osobas.Add(osoba);
                db.SaveChanges();
                */
                OsobaController.Osobe.Add(osoba);
                return RedirectToAction("Index");
            }

            return View(osoba);
        }

        // GET: Osobas/Edit/5
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //Osoba osoba = db.Osobas.Find(id);
            Osoba osoba = OsobaController.Osobe.Find(x => x.ID == id);
            if (osoba == null)
            {
                return HttpNotFound();
            }
            return View(osoba);
        }

        // POST: Osobas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Ime,Prezime")] Osoba osoba)
        {
            if (ModelState.IsValid)
            {
                //db.Entry(osoba).State = EntityState.Modified;
                //db.SaveChanges();
                Osoba myOsoba = OsobaController.Osobe.Find(x => x.ID == osoba.ID);
                myOsoba.Ime = osoba.Ime;
                myOsoba.Prezime = osoba.Prezime;

                return RedirectToAction("Index");
            }
            return View(osoba);
        }

        // GET: Osobas/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //Osoba osoba = db.Osobas.Find(id);
            Osoba osoba = OsobaController.Osobe.Find(x => x.ID == id);
            if (osoba == null)
            {
                return HttpNotFound();
            }
            return View(osoba);
        }

        // POST: Osobas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            //Osoba osoba = db.Osobas.Find(id);
            //db.Osobas.Remove(osoba);
            //db.SaveChanges();
            Osoba osoba = OsobaController.Osobe.Find(x => x.ID == id);
            OsobaController.Osobe.Remove(osoba);

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
