﻿debugger;

var urlPath = window.location.pathname;

$(function () {
    ko.applyBindings(vm);
    vm.load();
});

var vm = {
    Data: ko.observableArray([]),

    load: function () {
        var self = this;
        $.ajax({
            type: "GET",
            url: urlPath + '/GetIndex',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                self.Data(data);
            },
            error: function (err) {
                alert(err.status + " : " + err.statusText);
            }
        });

    }
};

function Data(data) {
    this.Ime = ko.observable(data.Ime);
    this.Prezime = ko.observable(data.Prezime);
}